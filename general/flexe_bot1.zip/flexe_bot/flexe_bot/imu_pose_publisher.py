import math
import rclpy
import numpy as np # Used for quaternion operations (e.g., normalization)
from rclpy.node import Node
from sensor_msgs.msg import Imu
from geometry_msgs.msg import TransformStamped
import tf2_ros
from tf_transformations import quaternion_multiply, quaternion_about_axis
from rclpy.parameter import Parameter

class GyroHandPosePublisher(Node):
    """
    ROS 2 Node that receives IMU messages, integrates gyroscope data (angular velocity)
    to estimate orientation, and broadcasts a tf2 transform for a hand model.
    """
    def __init__(self):
        super().__init__('gyro_hand_pose_publisher')
        self.get_logger().info("Gyro Hand Pose Publisher Node: Initializing...")

        # Initialize the tf2 broadcaster to send transforms
        self.tf_broadcaster = tf2_ros.TransformBroadcaster(self)

        # --- Declare and get parameters ---
        # Parameter to determine if simulation time should be used (e.g., in Gazebo)
        self.use_sim_time = self.get_parameter('use_sim_time').value
        self.get_logger().info(f"Gyro Hand Pose Publisher Node: use_sim_time: {self.use_sim_time}")

        # Parameter for the child frame ID of the hand model (e.g., 'hand_link')
        self.declare_parameter('hand_frame_id', 'base_link')
        self.hand_frame_id = self.get_parameter('hand_frame_id').value
        self.get_logger().info(f"Gyro Hand Pose Publisher Node: Hand frame ID: {self.hand_frame_id}")

        # --- Orientation State Variables ---
        # self.current_orientation: Stores the current estimated orientation of the hand.
        # It's a NumPy array [x, y, z, w] representing a quaternion.
        # Initialized to an identity quaternion (no rotation).
        self.current_orientation = np.array([0.0, 0.0, 0.0, 1.0]) # [x, y, z, w]

        # self.last_imu_timestamp: Stores the timestamp of the previously received
        # IMU message. This is crucial for calculating the time difference (delta_t)
        # needed for integration.
        self.last_imu_timestamp = None

        # --- ROS 2 Subscription ---
        # Subscribe to the IMU topic. This node expects raw angular velocity data.
        # The topic name '/imu/data_raw' is a common convention for raw IMU data.
        # Adjust this topic if your IMU publishes angular velocity on a different topic
        # (e.g., '/imu/data').
        self.imu_subscriber = self.create_subscription(
            Imu,
            '/imu/data_raw', # Subscribing to IMU messages for angular velocity
            self.imu_callback,
            10 # QoS history depth. This can be overridden by launch file QoS settings.
        )
        self.get_logger().info(f'Gyro Hand Pose Publisher Node: Subscribing to {self.imu_subscriber.topic_name} topic.')

    def imu_callback(self, msg: Imu):
        """
        Callback function for incoming Imu messages.
        Integrates angular velocity to update the hand's orientation.
        """
        # Get the current timestamp from the IMU message header
        current_timestamp = msg.header.stamp

        # Calculate time difference (delta_t) since the last message
        delta_t = 0.0
        if self.last_imu_timestamp is not None:
            # Convert ROS 2 Time messages (sec, nanosec) to a single float in seconds
            last_sec = self.last_imu_timestamp.sec + self.last_imu_timestamp.nanosec / 1e9
            current_sec = current_timestamp.sec + current_timestamp.nanosec / 1e9
            delta_t = current_sec - last_sec

            # Defensive check for negative delta_t (e.g., time reset or out-of-order messages)
            if delta_t < 0:
                self.get_logger().warn(
                    f"Negative delta_t ({delta_t:.4f}s) detected. "
                    "Resetting orientation and last timestamp to prevent instability."
                )
                self.current_orientation = np.array([0.0, 0.0, 0.0, 1.0]) # Reset to identity
                self.last_imu_timestamp = current_timestamp
                return # Skip this measurement

        # Store the current timestamp for the next iteration's delta_t calculation
        self.last_imu_timestamp = current_timestamp

        # Extract angular velocities (gyroscope readings) from the IMU message.
        # These are typically in radians per second (rad/s) in the IMU's body frame.
        wx = msg.angular_velocity.x
        wy = msg.angular_velocity.y
        wz = msg.angular_velocity.z

        # --- Gyroscope Integration Logic ---
        # Only perform integration if a valid time difference exists (not the very first message)
        # and there's actual angular motion.
        if delta_t > 0:
            # Calculate the magnitude of the angular velocity vector.
            # This represents the total rotational speed.
            omega_magnitude = math.sqrt(wx**2 + wy**2 + wz**2)

            # If there's significant angular velocity, compute the rotation increment.
            # We use a small threshold (1e-6) to avoid division by zero or
            # numerical instability for very small or zero rotations.
            if omega_magnitude > 1e-6:
                # The angle of rotation that occurred during this delta_t
                angle_increment = omega_magnitude * delta_t

                # The axis of rotation is the normalized angular velocity vector
                axis_x = wx / omega_magnitude
                axis_y = wy / omega_magnitude
                axis_z = wz / omega_magnitude

                # Create a quaternion (delta_q) representing this small incremental rotation
                # quaternion_about_axis(angle, axis_vector) returns [x, y, z, w]
                delta_q = quaternion_about_axis(angle_increment, [axis_x, axis_y, axis_z])

                # Update the current orientation by multiplying the current orientation
                # by the incremental rotation.
                # Quaternion multiplication order: `new_q = current_q * delta_q` if `delta_q`
                # represents a rotation in the *global* (world) frame.
                # `new_q = delta_q * current_q` if `delta_q` represents a rotation in the *body*
                # (sensor's local) frame, which is typically the case for IMU angular velocities.
                # Here, we assume angular_velocity is in the IMU's body frame, so we post-multiply.
                self.current_orientation = quaternion_multiply(self.current_orientation, delta_q)

                # Normalize the quaternion to prevent accumulation of floating-point errors
                # which can cause the quaternion to drift away from unit length.
                self.current_orientation = self.current_orientation / np.linalg.norm(self.current_orientation)
            else:
                # If angular velocity is negligible, orientation remains unchanged.
                # Log a debug message if needed, but typically not required.
                pass

        # --- Prepare and Broadcast Transform ---
        transform_stamped = TransformStamped()
        # Set the timestamp based on whether simulation time is enabled or real clock
        transform_stamped.header.stamp = (
            msg.header.stamp if self.use_sim_time else self.get_clock().now().to_msg()
        )
        transform_stamped.header.frame_id = 'world'         # Parent frame (fixed reference)
        transform_stamped.child_frame_id = self.hand_frame_id # Child frame (our hand model's frame)

        # Assign the calculated orientation to the transform's rotation
        # tf_transformations functions return quaternions in [x, y, z, w] format.
        transform_stamped.transform.rotation.x = self.current_orientation[0]
        transform_stamped.transform.rotation.y = self.current_orientation[1]
        transform_stamped.transform.rotation.z = self.current_orientation[2]
        transform_stamped.transform.rotation.w = self.current_orientation[3]

        # The translation remains fixed at the origin of the world frame,
        # as this node only handles rotation based on gyroscope data.
        transform_stamped.transform.translation.x = 0.0
        transform_stamped.transform.translation.y = 0.0
        transform_stamped.transform.translation.z = 0.0

        # Broadcast the transform, making it available to TF2 listeners (like RViz)
        self.tf_broadcaster.sendTransform(transform_stamped)


def main(args=None):
    """
    Main function to initialize and run the ROS 2 node.
    """
    rclpy.init(args=args) # Initialize ROS 2
    gyro_hand_pose_publisher = GyroHandPosePublisher()
    gyro_hand_pose_publisher.get_logger().info("Gyro Hand Pose Publisher Node: Entering rclpy.spin()...")
    try:
        # Keep the node running until interrupted (e.g., Ctrl+C)
        rclpy.spin(gyro_hand_pose_publisher)
    except KeyboardInterrupt:
        gyro_hand_pose_publisher.get_logger().info(
            "Gyro Hand Pose Publisher Node: Shutting down cleanly via KeyboardInterrupt."
        )
    finally:
        # Clean up: destroy the node and shut down ROS 2
        gyro_hand_pose_publisher.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
