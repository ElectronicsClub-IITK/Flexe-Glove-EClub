# import rclpy
# from rclpy.node import Node
# from sensor_msgs.msg import JointState
# import serial
# import time

# class JointPublisherFromSerial(Node):
#     def __init__(self):
#         super().__init__('joint_state_from_serial')

#         # customize this based on your URDF joint name + limits
#         self.joint_name = 'middle2_WS'
#         self.min_angle = -0.25       # min joint angle in radians
#         self.max_angle =  0.7   # max joint angle in radians

#         # connect to Arduino (make sure Serial Monitor is CLOSED)
#         try:
#             self.ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=1)
#             time.sleep(2)  # wait for Arduino to reset
#         except serial.SerialException:
#             self.get_logger().error("Could not open /dev/ttyUSB0. Is it in use?")
#             exit(1)

#         self.joint_pub = self.create_publisher(JointState, '/joint_states', 10)
#         self.timer = self.create_timer(0.05, self.timer_callback)

#         self.get_logger().info("JointPublisherFromSerial Node Started ✅")

#     def timer_callback(self):
#         if self.ser.in_waiting > 0:
#             try:
#                 line = self.ser.readline().decode('utf-8').strip()
#                 # Expected format: AccX,AccY,AccZ,GyroX,GyroY,GyroZ,qx,qy,qz,qw,PotAngle
#                 parts = line.split(',')

#                 # --- Validate and Parse Input ---
#                 if len(parts) == 11: # We now expect 11 parts
#                     pot_val = int(parts[10])

#                     mapped_angle = self.map_range(pot_val, 0, 1023, self.min_angle, self.max_angle)

#                     # full joint list
#                     self.joint_names = [
#                         'middle1_KU', 'bottom1_KU-1',
#                         'middle2_WS', 'bottom2_WS-1',
#                         'middle3_SR', 'bottom3_SR-1',
#                         'middle4_SE', 'bottom4_SE-1',
#                         'middle5_MA', 'bottom5_MA-1',
#                         'base_link_MA-2', 'base_link_SE-2',
#                         'base_link_SR-2', 'base_link_WS-2',
#                         'base_link_KU-2'
#                     ]
#                     positions = [0.0] * len(self.joint_names)

#                     # just change one joint's value
#                     idx = self.joint_names.index('middle3_SR')
#                     positions[idx] = mapped_angle

#                     msg = JointState()
#                     msg.header.stamp = self.get_clock().now().to_msg()
#                     msg.name = self.joint_names
#                     msg.position = positions

#                     self.joint_pub.publish(msg)
#                     self.get_logger().info(f"Updated middle3_SR: {mapped_angle:.2f} rad")

#             except Exception as e:
#                 self.get_logger().warn(f"Serial read error: {e}")

    
#     def map_range(self, x, in_min, in_max, out_min, out_max):
#         return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

# def main(args=None):
#     rclpy.init(args=args)
#     node = JointPublisherFromSerial()
#     rclpy.spin(node)
#     node.destroy_node()
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()


import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float32 # <--- NEW: Import Float32 for potentiometer data
import math # <--- NEW: Import math for math.pi

class JointPublisherFromSerial(Node):
    def __init__(self):
        super().__init__('joint_state_from_serial')
        self.get_logger().info("JointPublisherFromSerial Node Initializing...")

        # --- IMPORTANT: Configure your joint name and limits ---
        self.controlled_joint_name = 'middle3_SR' # Make sure this exactly matches your URDF joint name!
        self.min_angle = -0.25       # min joint angle in radians
        self.max_angle =  0.7    # max joint angle in radians


        # --- Publishers and Subscribers ---
        self.joint_pub = self.create_publisher(JointState, '/joint_states', 10)
        self.get_logger().info('Publishing JointState data to /joint_states topic.')

        # <--- NEW: Subscribe to potentiometer data from RealImuPublisher --->
        self.pot_sub = self.create_subscription(
            Float32,
            '/arduino/pot_raw', # Topic from RealImuPublisher
            self.pot_data_callback, # New callback function
            10
        )
        self.get_logger().info('Subscribing to /arduino/pot_raw topic.')
        # <--- END NEW --->

        # Initialize full joint list and current positions
        self.joint_names = [
            'middle1_KU', 'bottom1_KU-1',
            'middle2_WS', 'bottom2_WS-1',
            'middle3_SR', 'bottom3_SR-1',
            'middle4_SE', 'bottom4_SE-1',
            'middle5_MA', 'bottom5_MA-1',
            'base_link_MA-2', 'base_link_SE-2',
            'base_link_SR-2', 'base_link_WS-2',
            'base_link_KU-2'
        ]
        self.current_joint_positions = [0.0] * len(self.joint_names)

        # Pre-calculate index of the controlled joint for efficiency
        try:
            self.controlled_joint_idx = self.joint_names.index(self.controlled_joint_name)
        except ValueError:
            self.get_logger().error(f"Controlled joint '{self.controlled_joint_name}' not found in joint_names list. Please check your URDF and joint_names list.")
            # If the joint name is not found, the node will not be able to update its position
            self.controlled_joint_idx = -1 # Mark as invalid index

        self.get_logger().info("JointPublisherFromSerial Node Started ✅")

    def pot_data_callback(self, msg_float32): # <--- NEW: Callback for Float32 message
        """
        Callback function for incoming potentiometer data (Float32 message).
        Maps the data to the joint limits and publishes JointState.
        """
        if self.controlled_joint_idx == -1: # Check if joint name was found
            return

        pot_val = msg_float32.data # Extract the float data

        # Map the Arduino's output range to the actual joint's allowed range
        mapped_angle = self.map_range(pot_val, 0, 1023, self.min_angle, self.max_angle)
        
        # Update the position for the controlled joint
        self.current_joint_positions[self.controlled_joint_idx] = mapped_angle

        # Publish the JointState message
        joint_state_msg = JointState()
        joint_state_msg.header.stamp = self.get_clock().now().to_msg()
        joint_state_msg.name = self.joint_names
        joint_state_msg.position = self.current_joint_positions # Use the updated list

        self.joint_pub.publish(joint_state_msg)
        # self.get_logger().info(f"Updated {self.controlled_joint_name}: {mapped_angle:.4f} rad (from Arduino: {pot_angle_from_arduino:.4f} rad)")

    def map_range(self, x, in_min, in_max, out_min, out_max):
        """
        Maps a value from one range to another.
        Clamps the input value to the input range to prevent out-of-bounds mapping.
        """
        if in_min == in_max:
            return out_min
        
        x_clamped = max(in_min, min(x, in_max))
        return (x_clamped - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

def main(args=None):
    rclpy.init(args=args)
    node = JointPublisherFromSerial()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()